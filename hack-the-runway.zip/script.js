
var levisScore = 0; //levis
var adidasScore = 0; //adidas

var questionCount = 0; //question 

var result = document.getElementById("result");
var button = document.getElementById("restart");

var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");

var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");

var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");

q1a1.addEventListener("click", levis);
q1a2.addEventListener("click", adidas);

q2a1.addEventListener("click", adidas);
q2a2.addEventListener("click", levis);

q3a1.addEventListener("click", levis);
q3a2.addEventListener("click", adidas);

restart.addEventListener("click", restartButton);

function levis() {
  levisScore = levisScore +1;
   questionCount += 1

  console.log("questionCount = " + questionCount + "levisScore = " + levisScore);

  if (questionCount == 3) {
  console.log("Done!")
  updateResult();
  }
}

function adidas() {
  adidasScore = adidasScore +1;
   questionCount += 1

  console.log("questionCount = " + questionCount + "adidasScore = " + adidasScore);

  if (questionCount == 3) {
  console.log("Done!")
  updateResult();
  }
}



function updateResult () {
  if (levisScore >= 2) {
    result.innerHTML = "Levis!";
  console.log("Levis!");
}
  else if (adidasScore >= 2) {
    result.innerHTML = "Adidas";
  console.log("Adidas!");
}
}



function restartButton(){
  questionCount = 0;
  levisScore = 0;
  adidasScore = 0;
  result.innerHTML = "Your result is..."
}


function restartButton(){
  questionCount = 0;
  levisScore = 0;
  adidasScore = 0;
  result.innerHTML = "Your result is..."
}




function restartButton(){
  questionCount = 0;
  levisScore = 0;
  adidasScore = 0;
  result.innerHTML = "Your result is..."
}